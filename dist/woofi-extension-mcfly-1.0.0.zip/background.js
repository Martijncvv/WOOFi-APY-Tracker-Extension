/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./src/background/background.ts ***!
  \**************************************/
console.log('BACKGROUND script is running');

/******/ })()
;
//# sourceMappingURL=background.js.map