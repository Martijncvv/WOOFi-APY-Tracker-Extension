/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./src/contentScript/contentScript.ts ***!
  \********************************************/
console.log('CONTENTSCRIPT is running');

/******/ })()
;
//# sourceMappingURL=contentScript.js.map