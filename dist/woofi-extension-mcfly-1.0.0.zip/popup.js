/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/FooterField/FooterField.css":
/*!******************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/FooterField/FooterField.css ***!
  \******************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#footer-field {\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\n\tfont-size: 10px;\n\tbackground-color: #3c404b;\n}\n\n#WooFi_footer_icon {\n\theight: 10px;\n}\n\np {\n\tmargin: 8px 0;\n\tcolor: white;\n}\n", "",{"version":3,"sources":["webpack://./src/components/FooterField/FooterField.css"],"names":[],"mappings":"AAAA;CACC,aAAa;CACb,uBAAuB;CACvB,mBAAmB;;CAEnB,eAAe;CACf,yBAAyB;AAC1B;;AAEA;CACC,YAAY;AACb;;AAEA;CACC,aAAa;CACb,YAAY;AACb","sourcesContent":["#footer-field {\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\n\tfont-size: 10px;\n\tbackground-color: #3c404b;\n}\n\n#WooFi_footer_icon {\n\theight: 10px;\n}\n\np {\n\tmargin: 8px 0;\n\tcolor: white;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/HeaderField/HeaderField.css":
/*!******************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/HeaderField/HeaderField.css ***!
  \******************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "h1 {\n\tmargin: 0;\n\tfont-size: 20px;\n\tcolor: rgb(248, 248, 248);\n}\n\nimg {\n\tbackground: white;\n\theight: 40px;\n\tborder-radius: 20px;\n}\n\n#header {\n\tdisplay: flex;\n\talign-items: center;\n\tjustify-content: flex-start;\n\n\theight: 66px;\n\n\tbackground-image: linear-gradient(\n\t\t40deg,\n\t\t#4e8ff7,\n\t\t#4e8ff7 30%,\n\t\t#e0a555 70%,\n\t\t#e0a555\n\t);\n}\n\n#img-box {\n\t/* height: 42px;\n\twidth: 42px; */\n\tmargin: 0 16px;\n\tpadding: 6px;\n\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\n\tborder-radius: 5px;\n\t/* border-radius: 21px; */\n\t/* background-color: rgb(248, 248, 248); */\n}\n", "",{"version":3,"sources":["webpack://./src/components/HeaderField/HeaderField.css"],"names":[],"mappings":"AAAA;CACC,SAAS;CACT,eAAe;CACf,yBAAyB;AAC1B;;AAEA;CACC,iBAAiB;CACjB,YAAY;CACZ,mBAAmB;AACpB;;AAEA;CACC,aAAa;CACb,mBAAmB;CACnB,2BAA2B;;CAE3B,YAAY;;CAEZ;;;;;;EAMC;AACF;;AAEA;CACC;eACc;CACd,cAAc;CACd,YAAY;;CAEZ,aAAa;CACb,uBAAuB;CACvB,mBAAmB;;CAEnB,kBAAkB;CAClB,yBAAyB;CACzB,0CAA0C;AAC3C","sourcesContent":["h1 {\n\tmargin: 0;\n\tfont-size: 20px;\n\tcolor: rgb(248, 248, 248);\n}\n\nimg {\n\tbackground: white;\n\theight: 40px;\n\tborder-radius: 20px;\n}\n\n#header {\n\tdisplay: flex;\n\talign-items: center;\n\tjustify-content: flex-start;\n\n\theight: 66px;\n\n\tbackground-image: linear-gradient(\n\t\t40deg,\n\t\t#4e8ff7,\n\t\t#4e8ff7 30%,\n\t\t#e0a555 70%,\n\t\t#e0a555\n\t);\n}\n\n#img-box {\n\t/* height: 42px;\n\twidth: 42px; */\n\tmargin: 0 16px;\n\tpadding: 6px;\n\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\n\tborder-radius: 5px;\n\t/* border-radius: 21px; */\n\t/* background-color: rgb(248, 248, 248); */\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/InfoField/InfoField.css":
/*!**************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/InfoField/InfoField.css ***!
  \**************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".info-field-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 12px 0 7px;\n\t/* border-radius: 4px; */\n\t/* border-bottom: 1px solid rgb(231, 231, 231); */\n}\n\n.info-field-value {\n\tcolor: white;\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 14px;\n\ttext-transform: capitalize;\n}\n.info-field-symbol {\n\twidth: 40%;\n\tpadding-left: 8px;\n\t/* padding: 0px 0 0px 4px; */\n}\n", "",{"version":3,"sources":["webpack://./src/components/InfoField/InfoField.css"],"names":[],"mappings":"AAAA;CACC,aAAa;CACb,mBAAmB;CACnB,8BAA8B;CAC9B,cAAc;;CAEd,cAAc;CACd,mBAAmB;CACnB,wBAAwB;CACxB,iDAAiD;AAClD;;AAEA;CACC,YAAY;CACZ,SAAS;CACT,UAAU;CACV,UAAU;CACV,eAAe;CACf,0BAA0B;AAC3B;AACA;CACC,UAAU;CACV,iBAAiB;CACjB,4BAA4B;AAC7B","sourcesContent":[".info-field-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 12px 0 7px;\n\t/* border-radius: 4px; */\n\t/* border-bottom: 1px solid rgb(231, 231, 231); */\n}\n\n.info-field-value {\n\tcolor: white;\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 14px;\n\ttext-transform: capitalize;\n}\n.info-field-symbol {\n\twidth: 40%;\n\tpadding-left: 8px;\n\t/* padding: 0px 0 0px 4px; */\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/LinksField/LinksField.css":
/*!****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/LinksField/LinksField.css ***!
  \****************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#links-field {\n\tpadding: 8px 0 0px;\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\tbackground-color: #3c404b;\n\tborder-top: 1px solid #73bef4;\n}\n\n.link-icon {\n\theight: 18px;\n\tmargin: 0 6px;\n\tcursor: pointer;\n}\n\n.link-icon:hover {\n\t-webkit-filter: drop-shadow(0px 3px 5px rgba(0, 87, 183, 0.8));\n\tfilter: drop-shadow(0px 3px 5px rgba(0, 87, 183, 0.8));\n}\n", "",{"version":3,"sources":["webpack://./src/components/LinksField/LinksField.css"],"names":[],"mappings":"AAAA;CACC,kBAAkB;CAClB,aAAa;CACb,uBAAuB;CACvB,mBAAmB;CACnB,yBAAyB;CACzB,6BAA6B;AAC9B;;AAEA;CACC,YAAY;CACZ,aAAa;CACb,eAAe;AAChB;;AAEA;CACC,8DAA8D;CAC9D,sDAAsD;AACvD","sourcesContent":["#links-field {\n\tpadding: 8px 0 0px;\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n\tbackground-color: #3c404b;\n\tborder-top: 1px solid #73bef4;\n}\n\n.link-icon {\n\theight: 18px;\n\tmargin: 0 6px;\n\tcursor: pointer;\n}\n\n.link-icon:hover {\n\t-webkit-filter: drop-shadow(0px 3px 5px rgba(0, 87, 183, 0.8));\n\tfilter: drop-shadow(0px 3px 5px rgba(0, 87, 183, 0.8));\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css ***!
  \**************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".woonetwork-field-header-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 10px 0 6px 4px;\n\n\tcolor: #fefefe;\n\tbackground-color: #313641;\n\tborder-bottom: 1px solid #73bef4;\n}\n\n.woonetwork-field-header-value {\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 15px;\n\tfont-weight: 600;\n\ttext-transform: capitalize;\n}\n.woonetwork-field-header-logo {\n\twidth: 40%;\n}\n.woonetwork-field-header-logo img {\n\theight: 18px;\n\twidth: 18px;\n}\n", "",{"version":3,"sources":["webpack://./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css"],"names":[],"mappings":"AAAA;CACC,aAAa;CACb,mBAAmB;CACnB,8BAA8B;CAC9B,cAAc;;CAEd,cAAc;CACd,uBAAuB;;CAEvB,cAAc;CACd,yBAAyB;CACzB,gCAAgC;AACjC;;AAEA;CACC,SAAS;CACT,UAAU;CACV,UAAU;CACV,eAAe;CACf,gBAAgB;CAChB,0BAA0B;AAC3B;AACA;CACC,UAAU;AACX;AACA;CACC,YAAY;CACZ,WAAW;AACZ","sourcesContent":[".woonetwork-field-header-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 10px 0 6px 4px;\n\n\tcolor: #fefefe;\n\tbackground-color: #313641;\n\tborder-bottom: 1px solid #73bef4;\n}\n\n.woonetwork-field-header-value {\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 15px;\n\tfont-weight: 600;\n\ttext-transform: capitalize;\n}\n.woonetwork-field-header-logo {\n\twidth: 40%;\n}\n.woonetwork-field-header-logo img {\n\theight: 18px;\n\twidth: 18px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/components/YieldFieldHeader/YieldFieldHeader.css":
/*!****************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/components/YieldFieldHeader/YieldFieldHeader.css ***!
  \****************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".yield-field-header-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 10px 0 4px 0;\n\n\tcolor: #fefefe;\n\tbackground-color: #313641;\n\tborder-bottom: 1px solid #73bef4;\n}\n\n.yield-field-header-value {\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 15px;\n\tfont-weight: 600;\n\ttext-transform: capitalize;\n}\n.yield-field-header-logo {\n\twidth: 40%;\n\tpadding-left: 6px;\n}\n.yield-field-header-logo img {\n\theight: 18px;\n\twidth: 18px;\n}\n", "",{"version":3,"sources":["webpack://./src/components/YieldFieldHeader/YieldFieldHeader.css"],"names":[],"mappings":"AAAA;CACC,aAAa;CACb,mBAAmB;CACnB,8BAA8B;CAC9B,cAAc;;CAEd,cAAc;CACd,qBAAqB;;CAErB,cAAc;CACd,yBAAyB;CACzB,gCAAgC;AACjC;;AAEA;CACC,SAAS;CACT,UAAU;CACV,UAAU;CACV,eAAe;CACf,gBAAgB;CAChB,0BAA0B;AAC3B;AACA;CACC,UAAU;CACV,iBAAiB;AAClB;AACA;CACC,YAAY;CACZ,WAAW;AACZ","sourcesContent":[".yield-field-header-values {\n\tdisplay: flex;\n\tflex-direction: row;\n\tjustify-content: space-between;\n\tgap: 10px 20px;\n\n\tmargin: 0 16px;\n\tpadding: 10px 0 4px 0;\n\n\tcolor: #fefefe;\n\tbackground-color: #313641;\n\tborder-bottom: 1px solid #73bef4;\n}\n\n.yield-field-header-value {\n\tmargin: 0;\n\tpadding: 0;\n\twidth: 30%;\n\tfont-size: 15px;\n\tfont-weight: 600;\n\ttext-transform: capitalize;\n}\n.yield-field-header-logo {\n\twidth: 40%;\n\tpadding-left: 6px;\n}\n.yield-field-header-logo img {\n\theight: 18px;\n\twidth: 18px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css":
/*!*******************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css ***!
  \*******************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "body {\n\twidth: 330px;\n\theight: auto;\n\tpadding: 0;\n\tmargin: 0;\n\tbackground-color: #313641;\n}\n\n::-webkit-scrollbar {\n\twidth: 3px;\n}\n::-webkit-scrollbar-track {\n\tbox-shadow: inset 0 0 5px rgba(255, 255, 255, 0);\n}\n::-webkit-scrollbar-thumb {\n\tbackground: #e0a555;\n\tborder-radius: 2px;\n}\n", "",{"version":3,"sources":["webpack://./src/popup/popup.css"],"names":[],"mappings":"AAAA;CACC,YAAY;CACZ,YAAY;CACZ,UAAU;CACV,SAAS;CACT,yBAAyB;AAC1B;;AAEA;CACC,UAAU;AACX;AACA;CACC,gDAAgD;AACjD;AACA;CACC,mBAAmB;CACnB,kBAAkB;AACnB","sourcesContent":["body {\n\twidth: 330px;\n\theight: auto;\n\tpadding: 0;\n\tmargin: 0;\n\tbackground-color: #313641;\n}\n\n::-webkit-scrollbar {\n\twidth: 3px;\n}\n::-webkit-scrollbar-track {\n\tbox-shadow: inset 0 0 5px rgba(255, 255, 255, 0);\n}\n::-webkit-scrollbar-thumb {\n\tbackground: #e0a555;\n\tborder-radius: 2px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/components/FooterField/FooterField.css":
/*!****************************************************!*\
  !*** ./src/components/FooterField/FooterField.css ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_FooterField_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./FooterField.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/FooterField/FooterField.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_FooterField_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_FooterField_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/HeaderField/HeaderField.css":
/*!****************************************************!*\
  !*** ./src/components/HeaderField/HeaderField.css ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_HeaderField_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./HeaderField.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/HeaderField/HeaderField.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_HeaderField_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_HeaderField_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/InfoField/InfoField.css":
/*!************************************************!*\
  !*** ./src/components/InfoField/InfoField.css ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_InfoField_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./InfoField.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/InfoField/InfoField.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_InfoField_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_InfoField_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/LinksField/LinksField.css":
/*!**************************************************!*\
  !*** ./src/components/LinksField/LinksField.css ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_LinksField_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./LinksField.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/LinksField/LinksField.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_LinksField_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_LinksField_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css":
/*!************************************************************************!*\
  !*** ./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_WooNetworkFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./WooNetworkFieldHeader.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_WooNetworkFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_WooNetworkFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/YieldFieldHeader/YieldFieldHeader.css":
/*!**************************************************************!*\
  !*** ./src/components/YieldFieldHeader/YieldFieldHeader.css ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_YieldFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./YieldFieldHeader.css */ "./node_modules/css-loader/dist/cjs.js!./src/components/YieldFieldHeader/YieldFieldHeader.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_YieldFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_YieldFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/popup.css":
/*!*****************************!*\
  !*** ./src/popup/popup.css ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./popup.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/components/FooterField/FooterField.tsx":
/*!****************************************************!*\
  !*** ./src/components/FooterField/FooterField.tsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _FooterField_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FooterField.css */ "./src/components/FooterField/FooterField.css");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");


const WOOFiIcon = __webpack_require__(/*! ../../static/images/WOOFi_logo.png */ "./src/static/images/WOOFi_logo.png");
const FooterField = ({}) => {
    return (react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { id: "footer-field" },
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("p", null,
            "Powered by WOO Network API",
            ' ',
            react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { id: "WooFi_footer_icon", src: WOOFiIcon }),
            ' ')));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterField);


/***/ }),

/***/ "./src/components/FooterField/index.tsx":
/*!**********************************************!*\
  !*** ./src/components/FooterField/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _FooterField__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FooterField */ "./src/components/FooterField/FooterField.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_FooterField__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/components/HeaderField/HeaderField.tsx":
/*!****************************************************!*\
  !*** ./src/components/HeaderField/HeaderField.tsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HeaderField_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HeaderField.css */ "./src/components/HeaderField/HeaderField.css");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");


const WOOFiIcon = __webpack_require__(/*! ../../static/images/WOOFi_logo.png */ "./src/static/images/WOOFi_logo.png");
const HeaderField = ({}) => {
    return (react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { id: "header" },
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { id: "img-box" },
            react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { src: WOOFiIcon })),
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_1__.createElement("h1", null, "WOOFi APYs"))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderField);


/***/ }),

/***/ "./src/components/HeaderField/index.tsx":
/*!**********************************************!*\
  !*** ./src/components/HeaderField/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HeaderField__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HeaderField */ "./src/components/HeaderField/HeaderField.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_HeaderField__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/components/InfoField/InfoField.tsx":
/*!************************************************!*\
  !*** ./src/components/InfoField/InfoField.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _InfoField_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InfoField.css */ "./src/components/InfoField/InfoField.css");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");


const InfoField = ({ symbol, apy, tvl, index }) => {
    console.log(index);
    return (react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { className: "info-field-values", style: parseInt(index) % 2
            ? { backgroundColor: '#313641' }
            : { backgroundColor: '#3C404B', borderRadius: '4px' } },
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { className: "info-field-value info-field-symbol" }, symbol),
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { className: "info-field-value" }, tvl),
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { className: "info-field-value" }, apy)));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InfoField);


/***/ }),

/***/ "./src/components/InfoField/index.tsx":
/*!********************************************!*\
  !*** ./src/components/InfoField/index.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _InfoField__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InfoField */ "./src/components/InfoField/InfoField.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_InfoField__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/components/LinksField/LinksField.tsx":
/*!**************************************************!*\
  !*** ./src/components/LinksField/LinksField.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _LinksField_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LinksField.css */ "./src/components/LinksField/LinksField.css");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");


const WOOFiIcon = __webpack_require__(/*! ../../static/images/WOOFi_logo.png */ "./src/static/images/WOOFi_logo.png");
const TwitterIcon = __webpack_require__(/*! ../../static/images/Twitter_logo.png */ "./src/static/images/Twitter_logo.png");
const DiscordIcon = __webpack_require__(/*! ../../static/images/Discord_logo.png */ "./src/static/images/Discord_logo.png");
const TelegramIcon = __webpack_require__(/*! ../../static/images/Telegram_logo.png */ "./src/static/images/Telegram_logo.png");
const LinksField = ({ twitterHandle, discordHandle, telegramHandle, }) => {
    function handleOpenTab(link) {
        chrome.tabs.create({ url: link, selected: false });
    }
    return (react__WEBPACK_IMPORTED_MODULE_1__.createElement("div", { id: "links-field" },
        react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { className: "link-icon", src: WOOFiIcon, onClick: () => handleOpenTab(`https://fi.woo.org/earn/`) }),
        twitterHandle && (react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { className: "link-icon", src: TwitterIcon, onClick: () => handleOpenTab(`https://www.twitter.com/${twitterHandle}`) })),
        discordHandle && (react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { className: "link-icon", src: DiscordIcon, onClick: () => handleOpenTab(`https://discord.gg/mvnhMsZb`) })),
        telegramHandle && (react__WEBPACK_IMPORTED_MODULE_1__.createElement("img", { className: "link-icon", src: TelegramIcon, onClick: () => handleOpenTab(`https://t.me/${telegramHandle}`) }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LinksField);


/***/ }),

/***/ "./src/components/LinksField/index.tsx":
/*!*********************************************!*\
  !*** ./src/components/LinksField/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _LinksField__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LinksField */ "./src/components/LinksField/LinksField.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_LinksField__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.tsx":
/*!************************************************************************!*\
  !*** ./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.tsx ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _WooNetworkFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WooNetworkFieldHeader.css */ "./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.css");


const WooNetworkFieldHeader = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "woonetwork-field-header-values" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "woonetwork-field-header-value woonetwork-field-header-logo" }, "Total Volume"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "woonetwork-field-header-value" }, "WOOFi"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "woonetwork-field-header-value" }, "Futures")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WooNetworkFieldHeader);


/***/ }),

/***/ "./src/components/WooNetworkFieldHeader/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/WooNetworkFieldHeader/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _WooNetworkFieldHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WooNetworkFieldHeader */ "./src/components/WooNetworkFieldHeader/WooNetworkFieldHeader.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_WooNetworkFieldHeader__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/components/YieldFieldHeader/YieldFieldHeader.tsx":
/*!**************************************************************!*\
  !*** ./src/components/YieldFieldHeader/YieldFieldHeader.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _YieldFieldHeader_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./YieldFieldHeader.css */ "./src/components/YieldFieldHeader/YieldFieldHeader.css");


const YieldFieldHeader = ({ logo }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "yield-field-header-values" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "yield-field-header-value yield-field-header-logo" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: logo })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "yield-field-header-value" }, "TVL"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "yield-field-header-value" }, "APY")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (YieldFieldHeader);
// #E13F3F


/***/ }),

/***/ "./src/components/YieldFieldHeader/index.tsx":
/*!***************************************************!*\
  !*** ./src/components/YieldFieldHeader/index.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _YieldFieldHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./YieldFieldHeader */ "./src/components/YieldFieldHeader/YieldFieldHeader.tsx");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_YieldFieldHeader__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/popup/popup.tsx":
/*!*****************************!*\
  !*** ./src/popup/popup.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var _popup_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup.css */ "./src/popup/popup.css");
/* harmony import */ var _components_FooterField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/FooterField */ "./src/components/FooterField/index.tsx");
/* harmony import */ var _components_HeaderField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/HeaderField */ "./src/components/HeaderField/index.tsx");
/* harmony import */ var _components_InfoField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/InfoField */ "./src/components/InfoField/index.tsx");
/* harmony import */ var _components_YieldFieldHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/YieldFieldHeader */ "./src/components/YieldFieldHeader/index.tsx");
/* harmony import */ var _components_WooNetworkFieldHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/WooNetworkFieldHeader */ "./src/components/WooNetworkFieldHeader/index.tsx");
/* harmony import */ var _components_LinksField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/LinksField */ "./src/components/LinksField/index.tsx");
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/api */ "./src/utils/api.ts");
/* harmony import */ var _utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/amountFormatter */ "./src/utils/amountFormatter.ts");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};









const BscIcon = __webpack_require__(/*! ../static/images/BNB_logo.png */ "./src/static/images/BNB_logo.png");
const AvaxIcon = __webpack_require__(/*! ../static/images/AVAX_logo.png */ "./src/static/images/AVAX_logo.png");


const App = () => {
    const [bscNetworkEarnInfo, setBscNetworkEarnInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [avaxNetworkEarnInfo, setAvaxNetworkEarnInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [wooFiStakedInfo, setWooFiStakedInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [wooFi1DTotalVolume, setWooFi1DTotalVolume] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [wooNetworkInfo, setWooNetworkInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [wooNetworkFuturesVolume, setWooNetworkFuturesVolume] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    // const [wooNetwork, setWooNetworkVolume] = useState()
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        getFuturesInfo();
        getWooNetworkInfo();
        getWooFiVolumesInfo();
        getaWooFiApyInfo();
    }, []);
    function getaWooFiApyInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            let bscNetworkFetchedInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchBscNetworkInfo)();
            let bscTokensInfo = Object.values(bscNetworkFetchedInfo.data.auto_compounding);
            setBscNetworkEarnInfo(bscTokensInfo.sort(compare));
            let avaxNetworkFetchedInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchAvaxNetworkInfo)();
            let avaxTokensInfo = Object.values(avaxNetworkFetchedInfo.data.auto_compounding);
            setAvaxNetworkEarnInfo(avaxTokensInfo.sort(compare));
        });
    }
    function getWooNetworkInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            let wooNetworkfetchedInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchWooNetworkInfo)();
            setWooNetworkInfo(wooNetworkfetchedInfo);
        });
    }
    function getFuturesInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            let totalFuturesVolume = 0;
            let wooNetworkfetchedFuturesInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchWooNetworkFutureInfo)();
            for (let i = 0; i < wooNetworkfetchedFuturesInfo.rows.length; i++) {
                totalFuturesVolume +=
                    wooNetworkfetchedFuturesInfo.rows[i]['24h_volumn'] *
                        wooNetworkfetchedFuturesInfo.rows[i]['mark_price'];
            }
            setWooNetworkFuturesVolume(totalFuturesVolume);
        });
    }
    function getWooFiVolumesInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            let bsc1DVolumefetchedInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchBsc1DVolume)();
            let avax1DVolumefetchedInfo = yield (0,_utils_api__WEBPACK_IMPORTED_MODULE_9__.fetchAvax1DVolume)();
            let totalWooFiVolume = parseInt(bsc1DVolumefetchedInfo.data['24h_volume_usd']) +
                parseInt(avax1DVolumefetchedInfo.data['24h_volume_usd']);
            setWooFi1DTotalVolume(totalWooFiVolume);
        });
    }
    const compare = (a, b) => {
        if (a.apy > b.apy) {
            return -1;
        }
        if (a.apy < b.apy) {
            return 1;
        }
        return 0;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_HeaderField__WEBPACK_IMPORTED_MODULE_4__.default, null),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_WooNetworkFieldHeader__WEBPACK_IMPORTED_MODULE_7__.default, null),
        wooNetworkInfo && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_InfoField__WEBPACK_IMPORTED_MODULE_5__.default, { index: 2, symbol: `$${(0,_utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__.amountFormatter)(wooNetworkInfo.data.amount)}`, tvl: `$${(0,_utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__.amountFormatter)(wooFi1DTotalVolume / Math.pow(10, 18))}`, apy: `$${(0,_utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__.amountFormatter)(wooNetworkFuturesVolume)} ` })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_YieldFieldHeader__WEBPACK_IMPORTED_MODULE_6__.default, { logo: BscIcon }),
        bscNetworkEarnInfo.length > 0 &&
            bscNetworkEarnInfo.map((tokenInfo, index) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_InfoField__WEBPACK_IMPORTED_MODULE_5__.default, { key: index, index: index, symbol: tokenInfo.symbol.replaceAll('_', '-').replace('-LP', ''), tvl: `$${(0,_utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__.amountFormatter)(parseInt(tokenInfo.tvl) / Math.pow(10, 18))}`, apy: `${tokenInfo.apy.toPrecision(3)}%` }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_YieldFieldHeader__WEBPACK_IMPORTED_MODULE_6__.default, { logo: AvaxIcon }),
        avaxNetworkEarnInfo.length > 0 &&
            avaxNetworkEarnInfo.map((tokenInfo, index) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_InfoField__WEBPACK_IMPORTED_MODULE_5__.default, { key: index, index: index, symbol: tokenInfo.symbol.replaceAll('_', '-').replace('-LP', ''), tvl: `$${(0,_utils_amountFormatter__WEBPACK_IMPORTED_MODULE_10__.amountFormatter)(parseInt(tokenInfo.tvl) / Math.pow(10, 18))}`, apy: `${tokenInfo.apy.toPrecision(3)}%` }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_LinksField__WEBPACK_IMPORTED_MODULE_8__.default, { twitterHandle: "WOOnetwork", discordHandle: "woonetwork", telegramHandle: "woonetwork" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_FooterField__WEBPACK_IMPORTED_MODULE_3__.default, null)));
};
const root = document.createElement('div');
document.body.appendChild(root);
react_dom__WEBPACK_IMPORTED_MODULE_1__.render(react__WEBPACK_IMPORTED_MODULE_0__.createElement(App, null), root);


/***/ }),

/***/ "./src/utils/amountFormatter.ts":
/*!**************************************!*\
  !*** ./src/utils/amountFormatter.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "amountFormatter": () => (/* binding */ amountFormatter)
/* harmony export */ });
function amountFormatter(amount) {
    switch (true) {
        case amount === 0 || amount === null || amount === undefined:
            return 'Fetching';
        case amount >= 1000000000000000:
            return `${(amount / 1000000000000000).toPrecision(3)} Q`;
        case amount >= 1000000000000:
            return `${(amount / 1000000000000).toPrecision(3)} T`;
        case amount >= 1000000000:
            return `${(amount / 1000000000).toPrecision(3)} B`;
        case amount > 1000000:
            return `${(amount / 1000000).toPrecision(3)} M`;
        case amount > 10000:
            return `${(amount / 1000).toPrecision(3)} K`;
        case amount < 0.001:
            return `${amount.toPrecision(3)}`;
        default:
            return `${amount.toPrecision(4)}`;
    }
}


/***/ }),

/***/ "./src/utils/api.ts":
/*!**************************!*\
  !*** ./src/utils/api.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fetchBscNetworkInfo": () => (/* binding */ fetchBscNetworkInfo),
/* harmony export */   "fetchAvaxNetworkInfo": () => (/* binding */ fetchAvaxNetworkInfo),
/* harmony export */   "fetchWooNetworkInfo": () => (/* binding */ fetchWooNetworkInfo),
/* harmony export */   "fetchWooNetworkFutureInfo": () => (/* binding */ fetchWooNetworkFutureInfo),
/* harmony export */   "fetchBscStakedInfo": () => (/* binding */ fetchBscStakedInfo),
/* harmony export */   "fetchAvaxStakedInfo": () => (/* binding */ fetchAvaxStakedInfo),
/* harmony export */   "fetchAvax1DVolume": () => (/* binding */ fetchAvax1DVolume),
/* harmony export */   "fetchBsc1DVolume": () => (/* binding */ fetchBsc1DVolume)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const WOOFI_BSC_NETWORK_API = 'https://fi-api.woo.org/yield?&network=bsc';
const WOOFI_BSC_STAKING_API = 'https://fi-api.woo.org/staking?network=bsc';
const WOOFI_AVAX_NETWORK_API = 'https://fi-api.woo.org/yield?&network=avax';
const WOOFI_AVAX_STAKING_API = 'https://fi-api.woo.org/staking?network=avax';
const WOOFI_AVAX_1D_VOLUME_API = 'https://fi-api.woo.org/cumulate_stat?period=1m&network=avax';
const WOOFI_BSC_1D_VOLUME_API = 'https://fi-api.woo.org/cumulate_stat?period=1m&network=bsc';
const WOONETWORK_TOTAL_VOLUME_API = 'https://sapi.woo.org/wootrade/data';
const WOONETWORK_FUTURES_API = 'https://api.woo.org/v1/public/futures';
function fetchBscNetworkInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_BSC_NETWORK_API);
        if (!res.ok) {
            throw new Error(`Fetch error, bsc network info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchAvaxNetworkInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_AVAX_NETWORK_API);
        if (!res.ok) {
            throw new Error(`Fetch error, avax network info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchWooNetworkInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOONETWORK_TOTAL_VOLUME_API);
        if (!res.ok) {
            throw new Error(`Fetch error, total network volume info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchWooNetworkFutureInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOONETWORK_FUTURES_API);
        if (!res.ok) {
            throw new Error(`Fetch error, futures info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchBscStakedInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_BSC_STAKING_API);
        if (!res.ok) {
            throw new Error(`Fetch error, Bsc staking info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchAvaxStakedInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_AVAX_STAKING_API);
        if (!res.ok) {
            throw new Error(`Fetch error, Avax staking info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchAvax1DVolume() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_AVAX_1D_VOLUME_API);
        if (!res.ok) {
            throw new Error(`Fetch error, Avax staking info}`);
        }
        const data = yield res.json();
        return data;
    });
}
function fetchBsc1DVolume() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(WOOFI_BSC_1D_VOLUME_API);
        if (!res.ok) {
            throw new Error(`Fetch error, Avax staking info}`);
        }
        const data = yield res.json();
        return data;
    });
}
// https://sapi.woo.org/wootrade/data
// https://oss.woo.network/static/symbol_logo/DASH.png


/***/ }),

/***/ "./src/static/images/AVAX_logo.png":
/*!*****************************************!*\
  !*** ./src/static/images/AVAX_logo.png ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "e3237eddf7eaed4fe175.png";

/***/ }),

/***/ "./src/static/images/BNB_logo.png":
/*!****************************************!*\
  !*** ./src/static/images/BNB_logo.png ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "d72c25f5643cee4d7bed.png";

/***/ }),

/***/ "./src/static/images/Discord_logo.png":
/*!********************************************!*\
  !*** ./src/static/images/Discord_logo.png ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "95c6a2faa986d3290d24.png";

/***/ }),

/***/ "./src/static/images/Telegram_logo.png":
/*!*********************************************!*\
  !*** ./src/static/images/Telegram_logo.png ***!
  \*********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "5ad56302a9acccde0581.png";

/***/ }),

/***/ "./src/static/images/Twitter_logo.png":
/*!********************************************!*\
  !*** ./src/static/images/Twitter_logo.png ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "1cb2dbe4b41cba0867c8.png";

/***/ }),

/***/ "./src/static/images/WOOFi_logo.png":
/*!******************************************!*\
  !*** ./src/static/images/WOOFi_logo.png ***!
  \******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fde82952efe37937ab5e.png";

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					result = fn();
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			for(moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) var result = runtime(__webpack_require__);
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkukraine_donation_wallet_tracker_extension"] = self["webpackChunkukraine_donation_wallet_tracker_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_react-dom_index_js","vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_cssW-926fd9"], () => (__webpack_require__("./src/popup/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=popup.js.map